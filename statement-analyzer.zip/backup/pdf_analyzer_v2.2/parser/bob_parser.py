def parse_bob(file):
    return []