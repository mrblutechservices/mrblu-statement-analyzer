from .bank_detector import detect_bank
from .header_parser import extract_header_info

from .axis_parser import parse_axis
from .axis_header import parse_axis_header
from .bob_parser import parse_bob
from .idfc_parser import parse_idfc
from .sbi_parser import parse_sbi
from .idbi_parser import parse_idbi
from .boi_parser import parse_boi
from .iob_parser import parse_iob


def parse_pdf(file):

    # reset file pointer
    file.seek(0)

    bank = detect_bank(file)

    # reset again
    file.seek(0)

    header_info = extract_header_info(file)

    # reset again
    file.seek(0)

    transactions = []

    if bank == "Axis Bank":
        file.seek(0)
        transactions = parse_axis(file)

        file.seek(0)
        header_info = parse_axis_header(file)

        print("HEADER DATA:", header_info)

    elif bank == "Bank of Baroda":
        transactions = parse_bob(file)

    elif bank == "IDFC First Bank":
        transactions = parse_idfc(file)

    elif bank == "SBI":
        transactions = parse_sbi(file)

    elif bank == "IDBI":
        transactions = parse_idbi(file)

    elif bank == "Bank of India":
        transactions = parse_boi(file)

    elif bank == "Indian Overseas Bank":
        transactions = parse_iob(file)

    return {
        "transactions": transactions,
        "info": {
            "bank": bank,
            **header_info
        }
    }