import pdfplumber

def detect_bank(file):

    text = ""

    with pdfplumber.open(file) as pdf:

        for page in pdf.pages:

            t = page.extract_text()

            if t:
                text += t.upper()

    if "AXIS BANK" in text:
        return "Axis Bank"

    elif "IDFC FIRST BANK" in text:
        return "IDFC First Bank"

    elif "BANK OF BARODA" in text or "BARODA" in text:
        return "Bank of Baroda"

    elif "STATE BANK OF INDIA" in text or "SBI" in text:
        return "SBI"

    elif "BANK OF INDIA" in text:
        return "Bank of India"

    elif "INDIAN OVERSEAS BANK" in text:
        return "IOB"

    elif "IDBI BANK" in text:
        return "IDBI"

    return "Unknown"