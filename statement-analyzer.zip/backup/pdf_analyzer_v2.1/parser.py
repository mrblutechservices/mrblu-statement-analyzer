import pdfplumber
import pandas as pd
import re
import numpy as np

date_pattern = r"\d{2}[-/ ]?[A-Za-z]{3}[-/ ]?\d{4}|\d{2}/\d{2}/\d{4}|\d{2}-\d{2}-\d{4}"

COLUMN_MAP = {
    "date": ["date", "tran date", "transaction date"],
    "value_date": ["value date"],
    "description": ["description", "particulars", "narration", "remarks"],
    "debit": ["debit", "withdrawal", "dr"],
    "credit": ["credit", "deposit", "cr"],
    "balance": ["balance"],
    "cheque_no": ["cheque no", "chq no", "cheque"],
    "branch_code": ["init br", "branch code"]
}


def find_column(headers, names):
    headers = [str(h).lower() for h in headers]

    for name in names:
        for i, h in enumerate(headers):
            if name in h:
                return i
    return None


def detect_transaction_type(desc):

    if not desc:
        return ""

    desc = desc.upper()

    if "UPI" in desc:
        return "UPI"
    if "IMPS" in desc:
        return "IMPS"
    if "NEFT" in desc:
        return "NEFT"
    if "RTGS" in desc:
        return "RTGS"
    if "ATM" in desc:
        return "ATM"
    if "CHARGE" in desc:
        return "BANK CHARGE"

    return "OTHER"


def clean_amount(x):

    if not x:
        return ""

    x = str(x).upper()

    x = x.replace(",", "")
    x = x.replace("CR", "")
    x = x.replace("DR", "")

    x = re.sub(r"[^\d\.]", "", x)

    return x.strip()


def clean_description(text):

    if not text:
        return ""

    text = re.sub(r'\s+', ' ', str(text))
    return text.strip()


def extract_name(text):

    if not text:
        return "Unknown"

    text = str(text).upper()

    patterns = [
        r'/([A-Z ]{4,})$',
        r'/([A-Z ]{4,})/',
        r'UPI.*?/([A-Z ]{4,})',
        r'IMPS.*?/([A-Z ]{4,})',
        r'NEFT.*?/([A-Z ]{4,})'
    ]

    for p in patterns:
        m = re.search(p, text)
        if m:
            return m.group(1).strip()

    return "Unknown"


# -------- INFO --------

def extract_statement_info(pdf):

    info = {
        "bank": "",
        "account_holder": "",
        "account_number": "",
        "customer_id": "",
        "branch": "",
        "ifsc": "",
        "micr": "",
        "email": "",
        "period": ""
    }

    text = ""

    for page in pdf.pages:

        t = page.extract_text()

        if t:
            text += t + "\n"

    text = text.upper()

    if "AXIS BANK" in text:
        info["bank"] = "Axis Bank"

    if "BANK OF BARODA" in text:
        info["bank"] = "Bank of Baroda"

    if "IDFC FIRST BANK" in text:
        info["bank"] = "IDFC First Bank"

    m = re.search(r"ACCOUNT\s*NO\s*[:\-]?\s*([0-9X]+)", text)
    if m:
        info["account_number"] = m.group(1)

    m = re.search(r"CUSTOMER\s*ID\s*[:\-]?\s*([A-Z0-9]+)", text)
    if m:
        info["customer_id"] = m.group(1)

    m = re.search(r"\b[A-Z]{4}0[A-Z0-9]{6}\b", text)
    if m:
        info["ifsc"] = m.group(0)

    return info


# -------- TABLE PARSER --------

def parse_table(pdf):

    transactions = []

    for page in pdf.pages:

        tables = page.extract_tables()

        for table in tables:

            if not table:
                continue

            header = table[0]

            date_col = find_column(header, COLUMN_MAP["date"])
            desc_col = find_column(header, COLUMN_MAP["description"])
            debit_col = find_column(header, COLUMN_MAP["debit"])
            credit_col = find_column(header, COLUMN_MAP["credit"])
            bal_col = find_column(header, COLUMN_MAP["balance"])

            for row in table[1:]:

                if not row:
                    continue

                row = [str(x) if x else "" for x in row]

                if date_col is None:
                    continue

                if not re.search(date_pattern, row[date_col]):
                    continue

                desc = row[desc_col] if desc_col is not None else ""

                # -------- BOB STYLE AMOUNT DETECTION --------

                nums = re.findall(r"\d[\d,]*\.\d{2}", " ".join(row))

                row_debit = ""
                row_credit = ""
                row_balance = ""

                if nums:

                    amounts = [clean_amount(n) for n in nums]

                    if len(amounts) == 1:
                        row_debit = amounts[0]

                    elif len(amounts) >= 2:
                        row_debit = amounts[0]
                        row_balance = amounts[-1]

                # -------- NORMAL COLUMN VALUES --------

                debit_val = clean_amount(row[debit_col]) if debit_col is not None else ""
                credit_val = clean_amount(row[credit_col]) if credit_col is not None else ""
                bal_val = clean_amount(row[bal_col]) if bal_col is not None else ""

                # -------- FALLBACK FOR BOB --------

                if debit_val == "":
                    debit_val = row_debit

                if bal_val == "":
                    bal_val = row_balance

                transactions.append({

                    "Date": row[date_col],
                    "Value_Date": "",
                    "Description": clean_description(desc),
                    "Cheque_No": "",
                    "Debit": debit_val,
                    "Credit": credit_val,
                    "Balance": bal_val,
                    "Branch_Code": "",
                    "Party": extract_name(desc),
                    "Mode": detect_transaction_type(desc),
                    "Type": detect_transaction_type(desc)

                })

    return transactions


# -------- MAIN --------

def parse_pdf(file):

    import pdfplumber
    import re

    with pdfplumber.open(file) as pdf:

        text = ""

        for page in pdf.pages:
            t = page.extract_text()
            if t:
                text += t + "\n"

        text_lower = text.lower()

        # ---------------- ACCOUNT INFO ---------------- #

        info = {}

        text_upper = text.upper()

        if "AXIS BANK" in text_upper:
            info["bank"] = "Axis Bank"

        elif "BANK OF BARODA" in text_upper:
            info["bank"] = "Bank of Baroda"

        elif "IDFC FIRST BANK" in text_upper:
            info["bank"] = "IDFC First Bank"

        else:
            info["bank"] = ""


        acc_match = re.search(r"account\s*(no|number)\s*[:\-]?\s*([\dXx]+)", text, re.I)
        cust_match = re.search(r"customer\s*id\s*[:\-]?\s*([\dXx]+)", text, re.I)
        ifsc_match = re.search(r"ifsc\s*[:\-]?\s*([A-Z0-9]+)", text, re.I)
        email_match = re.search(r"[\w\.-]+@[\w\.-]+\.\w+", text)

        period_match = re.search(
            r"statement\s*period.*?(\d{2}[/-]\d{2}[/-]\d{4}).*?(\d{2}[/-]\d{2}[/-]\d{4})",
            text,
            re.I,
        )

        
        info["account_number"] = acc_match.group(2) if acc_match else ""
        info["customer_id"] = cust_match.group(1) if cust_match else ""
        info["ifsc"] = ifsc_match.group(1) if ifsc_match else ""
        info["email"] = email_match.group(0) if email_match else ""

        if period_match:
            info["period"] = period_match.group(1) + " to " + period_match.group(2)
        else:
            info["period"] = ""

        # ---------------- TRANSACTIONS ---------------- #

        transactions = []

        try:
            transactions = parse_table(pdf)
        except:
            transactions = []

        if not transactions:

            try:
                transactions = parse_bob_text(pdf)
            except:
                transactions = []

    return {
        "transactions": transactions,
        "info": info
    }




def parse_bob_text(pdf):

    transactions=[]

    text=""

    for page in pdf.pages:
        text += page.extract_text() + "\n"

    lines=text.split("\n")

    for i,line in enumerate(lines):

        if re.match(r"^\d{2}/\d{2}/\d{4}", line):

            parts=line.split()

            date=parts[0]

            desc=" ".join(parts[1:])

            debit=""
            credit=""
            balance=""

            amounts=re.findall(r"\d[\d,]*\.\d{2}",line)

            if amounts:

                if len(amounts)==1:
                    debit=clean_amount(amounts[0])

                if len(amounts)>=2:
                    debit=clean_amount(amounts[0])
                    balance=clean_amount(amounts[-1])

            transactions.append({

                "Date":date,
                "Value_Date":"",
                "Description":clean_description(desc),
                "Cheque_No":"",
                "Debit":debit,
                "Credit":credit,
                "Balance":balance,
                "Branch_Code":"",
                "Party":extract_name(desc),
                "Mode":detect_transaction_type(desc),
                "Type":detect_transaction_type(desc)

            })

    return transactions


def extract_account_info(text):

    info={}

    bank=""

    if "axis bank" in text.lower():
        bank="AXIS BANK"


    elif "bank of baroda" in text.lower() or "bob world" in text.lower():
        bank="BANK OF BARODA"


    elif "idfc first bank" in text.lower():
        bank="IDFC FIRST BANK"
        


    acc_match=re.search(r"(account\s*(no|number)\s*[:\-]?\s*([\dXx]+))",text,re.I)

    if acc_match:
        acc=acc_match.group(3)

    else:
        acc_match=re.search(r"\b\d{10,16}\b",text)
        acc=acc_match.group(0) if acc_match else ""


    cust_match=re.search(r"customer\s*id\s*[:\-]?\s*([\dXx]+)",text,re.I)
    ifsc_match=re.search(r"ifsc\s*[:\-]?\s*([A-Z0-9]+)",text,re.I)
    email_match=re.search(r"[\w\.-]+@[\w\.-]+\.\w+",text)
    period_match=re.search(r"statement\s*period.*?(\d{2}[/-]\d{2}[/-]\d{4}).*?(\d{2}[/-]\d{2}[/-]\d{4})",text,re.I)

    info["bank"]=bank
    info["account_number"]=acc
    info["customer_id"]=cust_match.group(1) if cust_match else ""
    info["ifsc"]=ifsc_match.group(1) if ifsc_match else ""
    info["email"]=email_match.group(0) if email_match else ""

    if period_match:
        info["period"]=period_match.group(1)+" to "+period_match.group(2)
    else:
        info["period"]=""

    return info