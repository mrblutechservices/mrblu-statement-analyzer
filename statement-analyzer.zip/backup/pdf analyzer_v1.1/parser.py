import pdfplumber
import pandas as pd
import re
import numpy as np


date_pattern = r"\d{2}[-/ ]?[A-Za-z]{3}[-/ ]?\d{4}|\d{2}/\d{2}/\d{4}|\d{2}-\d{2}-\d{4}"


def detect_transaction_type(desc):
    if not desc:
        return ""

    desc = desc.upper()

    if "UPI" in desc:
        return "UPI"

    if "IMPS" in desc:
        return "IMPS"

    if "NEFT" in desc:
        return "NEFT"

    if "RTGS" in desc:
        return "RTGS"

    if "ATM" in desc:
        return "ATM"

    if "CHARGE" in desc or "CHRG" in desc:
        return "BANK CHARGE"

    if "CASH" in desc:
        return "CASH"

    if "TRANSFER" in desc:
        return "TRANSFER"

    return "OTHER"


def extract_name(text):

    if not text:
        return "Unknown"

    text = str(text).upper()

    patterns = [

        r'/([A-Z ]{3,})/',

        r'/([A-Z ]{3,})$',

        r'UPI.*?/([A-Z ]{3,})',

        r'IMPS.*?/([A-Z ]{3,})',

        r'TO\s([A-Z ]{3,})',

        r'BY\s([A-Z ]{3,})',

        r'([A-Z]{4,})'

    ]

    for p in patterns:

        m = re.search(p, text)

        if m:

            name = m.group(1)

            name = re.sub(r'[^A-Z ]', '', name)

            return name.strip()

    return "Unknown"


def clean_columns(cols):

    seen = set()
    new_cols = []

    for c in cols:

        c = str(c).strip()

        if c == "":
            c = "col"

        i = 1
        base = c

        while c in seen:
            c = f"{base}_{i}"
            i += 1

        seen.add(c)
        new_cols.append(c)

    return new_cols


# -------- TABLE PARSER --------

def parse_table(file):

    rows = []

    with pdfplumber.open(file) as pdf:

        for page in pdf.pages:

            tables = page.extract_tables()

            for table in tables:

                if not table:
                    continue

                header = table[0]
                data_rows = table[1:]

                cleaned = []
                current = None

                for r in data_rows:

                    if not any(r):
                        continue

                    if r[0] and re.search(date_pattern, str(r[0])):

                        if current:
                            cleaned.append(current)

                        current = r

                    else:

                        if current:
                            for i, val in enumerate(r):
                                if val:
                                    current[i] = str(current[i]) + " " + str(val)

                if current:
                    cleaned.append(current)

                df = pd.DataFrame(cleaned, columns=header)

                df.columns = clean_columns(df.columns)

                df = df.fillna("")

                rows.append(df)

    if rows:

        data = pd.concat(rows, ignore_index=True)

        data = data[~data.astype(str).apply(

            data = data[~data["Description"].str.contains(
"STATEMENT|REGISTERED|ACCOUNT|BRANCH|PERIOD",
case=False,
na=False
)]


            lambda r: r.str.contains(
                "Tran Date|Particular|Balance|Description",
                case=False
            ).any(),
            axis=1
        )]

        for col in data.columns:

            name = str(col).lower()

            if "particular" in name or "narration" in name:
                data["Description"] = data[col]

        if "Description" not in data.columns:
            data["Description"] = ""

        data["Party"] = data.astype(str).apply(
            lambda r: extract_name(" ".join(r)),
            axis=1
        )

        data["Type"] = data["Description"].apply(detect_transaction_type)

        data = data.replace({np.nan: ""})
        data = data.fillna("")

        return data.to_dict(orient="records")

    return None


# -------- TEXT PARSER --------

def parse_text(file):

    rows = []

    with pdfplumber.open(file) as pdf:

        text = ""

        for page in pdf.pages:
            t = page.extract_text()

            if t:
                text += t + "\n"

    lines = text.split("\n")

    # merge split transaction lines
    merged_lines = []
    i = 0

    while i < len(lines):

        line = lines[i]

        if re.search(date_pattern, line):

            if i + 1 < len(lines) and not re.search(date_pattern, lines[i + 1]):
                line = line + " " + lines[i + 1]
                i += 1

        merged_lines.append(line)

        i += 1

    lines = merged_lines

    current = None

    for line in lines:

        if re.search(date_pattern, line):

            if current:
                rows.append(current)

            date_match = re.search(date_pattern, line)

            if date_match:
                date_val = date_match.group(0)
            else:
                date_val = line.strip()

            rest = line.replace(date_val, "").strip()

            current = {
                "Date": date_val,
                "Description": rest,
                "Debit": "",
                "Credit": "",
                "Balance": ""
            }

        elif current:

            nums = re.findall(r"\d[\d,]*\.\d{2}", line)

            if len(nums) >= 1:

                if current["Debit"] == "":
                    current["Debit"] = nums[0]

                current["Balance"] = nums[-1]

            else:

                current["Description"] += " " + line.strip()

    if current:
        rows.append(current)

    df = pd.DataFrame(rows)

    df = df.fillna("")
    df = df.replace({np.nan: ""})

    df["Party"] = df.astype(str).apply(
        lambda r: extract_name(" ".join(r)),
        axis=1
    )

    df["Type"] = df["Description"].apply(detect_transaction_type)

    return df.to_dict(orient="records")


# -------- MAIN PARSER --------

def parse_pdf(file):

    try:

        data = parse_table(file)

        if data and len(data) > 5:
            return data

    except:
        pass

    return parse_text(file)