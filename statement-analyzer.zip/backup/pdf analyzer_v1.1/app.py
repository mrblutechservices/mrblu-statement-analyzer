from flask import Flask,render_template,request,jsonify,send_file
import pandas as pd
from parser import parse_pdf

app=Flask(__name__)

data_store=[]

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/upload",methods=["POST"])
def upload():

    try:

        file=request.files["pdf"]

        data=parse_pdf(file)

        names=list(set([r.get("Party","Unknown") for r in data]))

        return jsonify({
            "data":data,
            "names":names
        })

    except Exception as e:

        return jsonify({
            "error":str(e)
        })

@app.route("/filter",methods=["POST"])
def filter_data():

    req=request.json

    df=pd.DataFrame(data_store)

    if req["column"] and req["value"]:
        df=df[df[req["column"]].str.contains(req["value"],case=False)]

    if req["amount"]:
        df=df[df.apply(lambda r: str(req["amount"]) in str(r.values),axis=1)]

    if req["type"]!="":
        df=df[df.apply(lambda r: req["type"].lower() in str(r.values).lower(),axis=1)]

    return jsonify(df.to_dict(orient="records"))

@app.route("/export_excel",methods=["POST"])
def export_excel():

    df=pd.DataFrame(request.json)

    path="result.xlsx"
    df.to_excel(path,index=False)

    return send_file(path,as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True, use_reloader=True)