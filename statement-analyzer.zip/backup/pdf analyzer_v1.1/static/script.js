let allData=[]

function upload(){

let file=document.getElementById("pdf").files[0]

let formData=new FormData()

formData.append("pdf",file)

fetch("/upload",{
method:"POST",
body:formData
})
.then(res=>res.json())
.then(data=>{

allData=data.data || []

if(allData.length==0){
alert("No transactions found in PDF")
return
}

populateColumns(Object.keys(allData[0]))

populateNames([...new Set(allData.map(x=>x.Party))])

renderTable(allData)

})

}




function renderTable(data){

let table=document.getElementById("table")

let thead=table.querySelector("thead")
let tbody=table.querySelector("tbody")

thead.innerHTML=""
tbody.innerHTML=""

if(data.length==0){
tbody.innerHTML="<tr><td colspan='20'>No Data Found</td></tr>"
return
}

let columns=Object.keys(data[0])

// HEADER
let headRow=document.createElement("tr")

columns.forEach(col=>{
let th=document.createElement("th")
th.innerText=col
headRow.appendChild(th)
})

thead.appendChild(headRow)

// BODY

data.forEach(row=>{

let tr=document.createElement("tr")

columns.forEach(col=>{

let td=document.createElement("td")

let value=row[col] || ""

td.innerText=value

tr.appendChild(td)

})

tbody.appendChild(tr)

})

}




function applyFilters(){

let name=document.getElementById("party").value
let type=document.getElementById("type").value

let result=[...allData]

if(name!="all"){
result=result.filter(x=>x.Party && x.Party.includes(name))
}

if(type=="debit"){
result=result.filter(x=>parseFloat(x.Debit)>0)
}

if(type=="credit"){
result=result.filter(x=>parseFloat(x.Credit)>0)
}

renderTable(result)

}




function download(){

fetch("/export_excel",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify(allData)
})
.then(res=>res.blob())
.then(blob=>{

let a=document.createElement("a")

a.href=URL.createObjectURL(blob)
a.download="statement.xlsx"
a.click()

})

}




function formatDate(date){

let d=new Date(date)

let day=String(d.getDate()).padStart(2,'0')
let month=String(d.getMonth()+1).padStart(2,'0')
let year=d.getFullYear()

return day+"-"+month+"-"+year

}

function populateNames(names){

let select=document.getElementById("party")

select.innerHTML='<option value="all">All Parties</option>'

names.forEach(n=>{

let opt=document.createElement("option")

opt.value=n
opt.text=n

select.appendChild(opt)

})

}


function populateColumns(cols){

let select=document.getElementById("column")

if(!select) return

select.innerHTML=""

cols.forEach(c=>{

let option=document.createElement("option")

option.value=c
option.text=c

select.appendChild(option)

})

}